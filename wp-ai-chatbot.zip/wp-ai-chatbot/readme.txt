=== AK Deep Knowledge AI Chatbot ===
Contributors: akdeepknowledge
Tags: ai chatbot, chatbot, woocommerce, openai, gemini
Requires at least: 5.8
Tested up to: 6.8
Requires PHP: 7.4
Stable tag: 2.0.0
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

AI chatbot for WordPress and WooCommerce. It answers visitors from your own content (RAG), captures leads, and works with Google Gemini or OpenAI.

== Description ==

The chatbot reads your products, pages, posts, courses and custom data tables, turns them into a searchable knowledge base, and answers visitor questions from that knowledge instead of guessing.

**Features**

* Answers from your own content (WooCommerce products, pages, posts, Tutor LMS courses, custom databases and PDF documents) using vector search (RAG).
* PDF documents: add brochures, price lists, menus, manuals or policies from the Media Library and the bot answers from them too, with a download link to the PDF if you allow it. Text is read on your own server (no outside service). Long PDFs are learned part by part, so they work even on hosts with short time limits.
* Works with Google Gemini (free tier available) or OpenAI.
* Grounded answers: the bot is instructed to answer only from your content and to offer your contact form when it is not sure. Each reply is also checked: links must be in your content or exist on your site, emails and phone numbers must match your content exactly, and prices must be a price from your content in a matching currency (when a sentence names a product, it must be that product's price). Anything else is removed or replaced with "please confirm". Prices the AI calculates itself (totals, discounts) are replaced too. The check covers these four kinds of detail only and does not check ordinary sentences, so, like any AI, it cannot guarantee every answer is correct.
* Knowledge stays fresh: pages, posts, products, courses and knowledge base rows are queued for re-indexing when you change them (WP-Cron runs the queue on the next visit to your site, usually within minutes; on low-traffic sites set up a real cron job). An hourly check catches anything missed.
* Long pages are split into overlapping chunks of about 1,600 characters, up to 40 chunks (about 60,000 characters) per item. Text beyond that is not indexed; split very long pages into several pages.
* Lead capture forms the AI can show during a conversation, plus quick-action buttons and an optional pre-chat form.
* Guided first questions, a WhatsApp button and a WooCommerce "Order on WhatsApp" button.
* Chat logs, a leads manager with CSV export, and an analytics dashboard with a built-in "Data Analyst" assistant.
* AK Deep Knowledge light and dark themes plus 70+ ready-made templates, with a live preview while you edit.
* 36 animated chat icons: 13 chatbot icons (AKDK Bot, Typing Bubble, AI Spark, Conversation, Visor Bot, Orbit Bot, Voice Bot, Cube Bot, Capsule Bot, Live Bot, Help Bot, Support Buddy, Retro Robo) and 23 fun characters (Kitty, Puppy, Red Panda, Bunny, Foxy, Hoot, Penguin, Chick, Froggy, Busy Bee, Octo, Jelly, Boo, Alien, Monster, Dino, UFO, Rocket, Fluffy, Cool Sun, Love, Donut, Chai), with a greeting bubble, your own colours and light or dark website versions, or your own image or GIF from a link.
* Optional voice input (browser speech recognition) and a small JavaScript API (window.wpAiChatbot) for add-ons.
* Step-by-step setup guide in the admin, fully mobile-friendly.
* Replies in the visitor's language (for example English or Roman Urdu).

== Installation ==

1. Upload the `wp-ai-chatbot` folder to `/wp-content/plugins/`, or upload the zip under Plugins → Add New → Upload Plugin.
2. Activate the plugin.
3. Go to **AI Chatbot → Settings**, choose Gemini or OpenAI, paste your API key, save, and click **Test Connection**.
4. Go to **AI Chatbot → Vector RAG DB**, choose what the bot should learn from and click **Process & Index Selected Sources**.
5. Visit your site and open the chat bubble.

== Frequently Asked Questions ==

= How does Live Chat work? =
Open AI Chatbot > Live Chat and keep the page open: you are shown as online. Chats where a visitor asked for a person are at the top. Write a reply and the bot stops answering that chat until you click "Hand back to bot". The words that ask for a person and the messages are under "Live chat settings" on the same page.

= How do I connect WhatsApp? =
AI Chatbot > Sales Tools > WhatsApp AI. Choose the connection. WAHA or Evolution API: enter the server address, API key and session / instance name, and paste the Webhook URL shown there into the gateway (WAHA event "message", Evolution event MESSAGES_UPSERT). The gateway and the website must reach each other: a gateway only on your own computer (localhost) needs a server or a tunnel. Meta Cloud API: you need a WhatsApp Business number in Meta's Cloud API (developers.facebook.com): copy the Phone number ID, a permanent access token and the App secret into the plugin, then paste the Callback URL and Verify token shown there into Meta (WhatsApp > Configuration) and subscribe to "messages". The site must use HTTPS.

= Can I show the chatbot inside a page instead of the floating button? =

Yes. Add `[akdk_chatbot]` to any page (or click AI Chatbot > AI Settings > Create chat page). Example: `[akdk_chatbot height="80vh" width="900" title="Support" welcome="Hi! Ask me anything."]`. The width is limited by your theme's content width; use a full-width page template for a wider chat.


= Which AI models are used? =

By default `gemini-3.8-flash` for chat and `gemini-embedding-2` for the knowledge base (Gemini), or `gpt-4o-mini` and `text-embedding-3-small` (OpenAI). You can enter any other model name in the settings. Models that Google has retired are replaced automatically.

= I changed the embedding model. What now? =

Re-index the knowledge base (Vector RAG DB → Process & Index). Items indexed with a different model are ignored until they are refreshed, and a notice reminds you.

= How are tokens counted? =

Token numbers on the Dashboard come from the AI provider's own usage report (OpenAI and Gemini chat). Gemini embeddings do not report usage, so those are estimated; the Dashboard shows which share of chats is exact. The cost includes chats, the admin assistant and knowledge base indexing. Built-in prices exist only for gpt-4o-mini and text-embedding-3-small; for other models enter your prices under Dashboard, Design, Cost estimate. The cost is always an estimate.

= How does the Token saver work? Can I turn it off? =

AI Settings, Token saver (on by default). For each message the bot sends the AI only the passages that answer it, within a size budget: a few sources for a simple question, more for comparisons and questions with several parts (each part keeps its own best sources). "Show all" requests send 10 compact items at a time and the visitor can say "show more" for the next ones. Old replies in the conversation are shortened (image cards become links), the instructions are written once and short, and simple questions get a smaller answer limit. Untick the box to go back to the previous behaviour. Developers can tune it with the filters wp_ai_chatbot_input_budget, wp_ai_chatbot_evidence_floor and wp_ai_chatbot_answer_tokens or the constant WP_AI_CHATBOT_CONTEXT_BUDGET.

= How do I verify leads from external forms? =

WordPress forms (Contact Form 7, WPForms, Fluent Forms, Gravity Forms, Ninja Forms, Forminator, Elementor) are confirmed automatically when they are submitted inside the chat; the plugin checks that the submitted form is the one set in the chat form's shortcode. For Google Forms, Typeform, Calendly, payment links and others, use the webhook link shown under Lead Forms, "Verified submissions" (a ready Apps Script is included for Google Forms; n8n, Zapier and Make also work). Send a unique submission_id so retries are never counted twice. Only confirmed submissions count as leads.

= How big can the knowledge base be? =

Search compares each new question with every stored vector in PHP (repeated questions are cached). A few thousand items is fine on normal hosting. Above 20,000 vectors the Vector RAG DB screen shows a note: index only what visitors need, or set `WP_AI_CHATBOT_RAG_SCAN_CAP` in wp-config.php.

= Does it work with page caching? =

Yes. Visitors do not need a fresh security token, so cached pages keep working. Requests are rate-limited per IP address.

= Is my data deleted when I delete the plugin? =

No, unless you tick "Delete all chatbot data when the plugin is deleted" under AI Chatbot → Settings.

= Which PDFs can the bot learn? =

PDFs that contain real text, for example exported from Word, Google Docs or Canva. Scanned PDFs (photos of pages) have no text to read; the screen says so, and you can run them through OCR first. Password-protected PDFs must be saved without a password. Up to 20 MB per file and about 480,000 characters (roughly 200 pages of dense text) per PDF; split bigger documents. Developers can change the limits with `WP_AI_CHATBOT_PDF_MAX_MB` and `WP_AI_CHATBOT_PDF_MAX_SECTIONS` in wp-config.php.

= What happens when I replace or delete a PDF? =

If the file changes, it is learned again on the next Process & Index (or by the hourly check). Deleting the PDF from the Media Library removes it from the bot. Remove on the Vector RAG DB screen only takes it out of the bot; the file stays in your Media Library.

== Third-party libraries ==

* PdfParser by Sébastien Malot (LGPL-3.0, https://github.com/smalot/pdfparser), bundled in vendor/pdfparser with its own namespace so it never clashes with other plugins.
* Select2 (MIT, https://github.com/select2/select2), bundled in vendor/select2 instead of being loaded from a CDN.

== Changelog ==

= 2.0.0 =
Sales tools. Nothing changes until you use them; all earlier settings stay as they are.

* New: Live Chat (AI Chatbot > Live Chat). A visitor who asks for a person ("talk to a human", "kisi insaan se baat") or taps "Talk to a person" after the bot was not sure goes to an inbox with their whole chat. Take over and reply; your message shows in the visitor's chat within seconds and the bot stays quiet until you hand the chat back. You get an email when someone is waiting. When nobody has the Live Chat page open, the visitor is told the team will reply and the bot keeps helping.
* New: WooCommerce order status. "Where is my order?", "track order #1234", "mera order kahan hai": the bot asks for the order number and the email or phone used for the order and shows the status, total, items and tracking number only when both match (logged-in customers only need the number). After 5 wrong tries the chat is blocked for an hour. Answered straight from WooCommerce: no AI tokens.
* New: product cards. Products the bot recommends appear as cards with photo, price, Add to cart (the cart updates without leaving the chat) and Buy now (straight to checkout). Products with options get "Choose options", out-of-stock products say so.
* New: proactive messages. The bot starts the conversation after some seconds, after scrolling, or when the visitor is about to leave, on any page, a page whose address contains a word (for example /pricing), product, shop, cart or checkout pages, or while the cart has products (abandoned cart). Shown as a bubble next to the chat button or by opening the chat; once per visit, per day or per visitor.
* New: multiple bots. Separate bots per page or per client, each with its own name, colour, welcome message, instructions and knowledge (for example only products or only PDFs). Chosen by page address or ID, or with [akdk_chatbot bot="id"]. Each bot keeps its own conversation.
* New: the same AI on WhatsApp. Connect Meta's official WhatsApp Business Cloud API, or your normal WhatsApp through a self-hosted gateway: WAHA, Evolution API, or any other gateway / n8n flow (custom send URL). Same knowledge, order status (checked against the customer's WhatsApp number) and live chat; agent replies from Live Chat are sent on WhatsApp. Webhooks are signed (Meta) or carry a secret key (gateways), each message is answered once, groups and status updates are skipped, and a "Send test message" button checks the connection.
* New: AI summary and lead score. Chats that ended get a 2-line summary, the visitor's intent and a score from 0 to 100 (Hot, Warm, Cold). Chat History shows them, filters "Hot leads", sorts by score and has "Summarize now"; optional email for hot leads.
* New: WPML and Polylang. The bot answers in the language of the page, prefers knowledge in that language, and the chat's texts (name, welcome, placeholder, messages, buttons) can be translated in String Translation.
* All of this is under the new AI Chatbot > Sales Tools page (Store, Proactive messages, Bots, WhatsApp AI, Lead score).
* Chat History shows team replies, live chat events, WhatsApp chats, the bot that answered and the page the chat started on.
* Fix: on block themes the chat's script data could be printed twice on pages with [akdk_chatbot].

= 1.9.6 =
* New: chat page shortcode. `[akdk_chatbot]` shows the chatbot inside any page or post (Gutenberg Shortcode block, Elementor Shortcode widget, classic editor), for example a full "Chat with us" page. Options: height ("700" or "80vh"), width, title, subtitle, header="no" and welcome (first message of a new chat). `[ak_chatbot]` and `[wp_ai_chatbot]` work too.
* The chat page uses the same knowledge, forms, quick actions, voice, look and conversation as the floating chat. It is always open (no close button), stays in the page on phones instead of going full screen, and the floating chat button is hidden on that page. One chat per page.
* New: AI Settings > Chat page card with the shortcode, a Copy button and "Create chat page" (makes a published "Chat with us" page in one click).

* New: Direct Link form type. A Quick Action button that opens your link in the same tab, without adding anything to the chat. Direct Links are never offered by the AI and cannot be chosen as the pre-chat form.
* Fix: lead forms made or changed by older versions could refuse every visitor with "This form needs administrator repair". Missing columns are now added and fields changed to Long text or Checkboxes become long-text columns automatically, the first time someone submits (and whenever the form is saved).
* Fix: with Off-topic questions turned on and an empty or not yet trained knowledge base, every real question got the off-topic message. The check now runs only when there is something to compare with (and not when search is turned off).
* Fix: a reply that only contained a Direct Link code left an empty bubble in the chat.
* Fix: the Automatic model list of a key that was replaced by a key that does not work kept showing the old key's models. The list is also checked weekly by itself now, not only when settings are saved.
* Fix: SMTP passwords containing a backslash or spaces were saved wrongly.
* Fix: lead alert emails could list internal "form shown" markers as visitor questions.
* Fix: the leads PDF export lost accented letters (é, ü) because the text was converted twice.
* Test connection now says when Simple mode or "Search & voice off" means there is no search to test, instead of reporting a failed embedding.
* Deleting the plugin with "Delete all chatbot data" now also removes the lead-column backups and the newer cached data.

* New: Chat History > Unanswered questions. Questions the bot could not answer (it was not sure, or the fact check removed a price, number or link) are collected with how many times they were asked. Add answer once and the bot uses it from then on (Smart mode: added to the knowledge; Simple mode: sent with the business details). Mark done, Ignore, Move back to New, Delete, search and New / Answered / Ignored filters.
* Conversations tag these replies ("Not answered" / "Answer added"); "View chat" opens the exact chat. The Dashboard shows a card while questions are waiting.
* Bigger icons: Lead Forms open/close arrows and the Chat History settings panel.

= 1.9.3 =
* Chat History: when a visitor fills any lead form or the pre-chat form in the chat, the chat shows their name (or email or phone) instead of the ID, with a link to the lead. Works for full name, first + last name, and "naam" fields.
* Chat History redesigned: search by name, phone, email or message; All / With name / IDs only filters; every chat shows input (I) and output (O) message counts and input/output tokens; the open chat shows its contact details and five stat cards (input messages, output messages, input tokens, output tokens, total tokens).

= 1.9.2 =
* Visitor chat history settings moved to the Chat History page ("Visitor chat history settings" panel), with a Custom time (minutes, hours or days, up to 365 days). The "Clear all visitors' chat history" button is there too.

= 1.9.1 =
* New: AI Settings > Visitor chat history. Choose when a visitor's chat is cleared from their screen: never, when the browser tab closes, or after 5 minutes to 30 days without activity.
* New: "Clear all visitors' chat history" button. Clears the chat on every visitor's screen within seconds, open chats included. Admin chat logs, dashboard data and leads are never deleted.

= 1.9.0 =
* New: Chatbot mode in AI Settings. Smart mode (as before) learns your pages, PDFs and products. Simple mode answers only from business details you type in (name, what you do, services and prices, timings, contact, common questions): no training and no search key needed.
* Simple mode shows how many tokens the details add to each message. Unrelated questions get your off-topic message (the AI declines them itself, since there is no search). Train Chatbot shows that Simple mode is on; search and re-index warnings are hidden.
* Switching modes deletes nothing.

= 1.8.9 =
* AI Settings: the model choice appears only after a working API key is saved, for every provider. With no key, or a key the provider rejects, a short message says what to do instead (the reason is shown for a rejected key).

= 1.8.8 =
* AI Settings: with Claude, DeepSeek, Grok or Mistral, the Gemini and OpenAI key boxes are replaced by one "Search & voice" box. A saved Gemini or OpenAI key is shown as it is; with no key you choose Gemini (free) or OpenAI.
* Search & voice can be turned off. The box fades, website search and voice stop, and the bot answers from your instructions only. A warning on the plugin screens says so. Saved keys are kept.

= 1.8.7 =
* AI Settings: with Claude, DeepSeek, Grok or Mistral, the Gemini key box explains in plain words why it is still needed (search of your website and PDFs, voice input), that it is free, and that an OpenAI key can do the search instead (with where to switch it). The OpenAI key box is shown as optional, and the page says which provider does the search now.

= 1.8.6 =
* Automatic model choice: when an API key is saved, the plugin asks the provider which models the key can use and picks the cheapest good chat model (newest Gemini Flash-Lite, GPT mini, Claude Haiku, DeepSeek Flash, Grok fast / non-reasoning, Mistral Small). Every provider's model box is now a list: Automatic (default), any model the key can use, or a name typed by hand. The list is checked again weekly, when the key changes, or with Refresh list; previews, audio, image, embedding and code models are left out.

= 1.8.5 =
* New AI providers for the chatbot's answers: Anthropic (Claude), DeepSeek, xAI (Grok) and Mistral, next to Gemini and OpenAI. Each has its own key and model box (empty = recommended model: claude-haiku-5-5, deepseek-flash, grok-4.3, mistral-small-latest) and a link to get a key. Knowledge search keeps using Gemini or OpenAI and voice keeps using Gemini; the settings page says so when another provider is chosen.
* Clearer provider errors (also for providers that report errors in their own format).

= 1.8.4 =
* Lead Forms: each form folds into one line (name, type and number of fields), with a button to open or close it and Expand all / Collapse all. Saved forms start folded; a form with a missing required box opens by itself when saving. "How it works" is folded too.

= 1.8.3 =
* Lead Forms made simpler: a saved form shows its type as a badge and only changes after "Change type"; switching type keeps the fields, link and code of the other types, so switching back loses nothing. Clear explanation of where leads go and when the visitor gets an email (only from an "Email address" box), with a warning when a form has none. Clearer answer types, an optional hint (placeholder) per field, and new forms start with Name, Email and Phone.
* Fix: form labels were invisible on dark chat designs when the theme colours all labels; form boxes, typed text and hints now always use a readable colour for their background (also the message box and mic).
* Fix: adding a new form could break the Lead Forms page (text spilling below the forms).

= 1.8.2 =
* Voice input fixed: the speech detector is started inside the mic tap, so browsers no longer keep it paused (it used to wait 8 seconds and then say "Didn't catch that").
* Voice is faster: recording stops 0.9 seconds after the visitor stops talking, and Gemini is asked to transcribe without thinking.
* Spoken words now go into the message box (live while speaking, where the browser supports it) so the visitor can check them and press send.
* Clearer voice messages: no microphone, no internet, no speech.
* New: Token control section under AI Settings, with every token setting in one place: Knowledge per question (Economy / Balanced / Detailed), Answer length (Short / Normal / Detailed), Conversation memory, Daily token limit for the whole site (with your own message when it is reached; no AI call, no tokens until midnight), Messages per visitor per day, and Voice message length. Shows the tokens used today.
* New: Off-topic questions (Token control). A question that matches your knowledge base no better than typical off-topic questions (jokes, cricket, weather; measured once on your own content and embedding model) gets your own fixed message instead of an AI answer: no AI call, no tokens. Strictness: Relaxed / Normal / Strict. Greetings, buying/contact words (editable list) and form names always reach the AI; follow-ups are judged together with the previous question. Off by default.
* New: Lead Alerts & Email page. An email the moment a visitor submits a chat form: their details, Call / WhatsApp / Reply buttons and the questions they asked the bot. Several recipients, your own subject, and a country code so local numbers get working WhatsApp links. Sent after the visitor has their answer, so the form never waits for the mail server.
* New: optional thank-you email to the visitor (your own subject and message, {name}/{site}/{form}).
* New: choose how emails are sent: WordPress default (works with WP Mail SMTP, FluentSMTP and other SMTP plugins, which are detected) or the plugin's own SMTP with one-click settings for Gmail, Outlook, Zoho, Hostinger, cPanel and Brevo. The plugin's SMTP is used for the chatbot's emails only. Test email button with plain-language fixes for common errors; failed emails show on the dashboard.
* Voice transcription is capped at 400 output tokens, so a stuck answer can no longer run until the 30-second timeout.

= 1.8.1 =
* Fix: visitors who were not logged in could get "Cookie check failed" (403) instead of an answer, mostly on sites with page caching (cache plugin, Cloudflare or hosting cache). The chat sent a security nonce that had expired in the cached page, and WordPress rejected it. Visitors now send no nonce (the chat never needed one for them), and a logged-in user whose nonce expired is retried automatically instead of seeing an error. Applies to chat messages, lead forms and voice input.

= 1.8.0 =
* New: PDF documents as a knowledge source (Vector RAG DB, section 3). Add PDFs from the Media Library or upload new ones, see pages, parts and status for each, re-index or remove with one click. Scanned and password-protected PDFs are detected and explained. Optional download link to the PDF in answers. Urdu and Arabic text that some PDF writers store backwards is put back in reading order.
* New: PDFs are part of Process & Index, the hourly check and automatic clean-up (deleted, removed or replaced files). The PDF list is stored separately, so saving the other knowledge base settings never touches it.
* Faster search: vectors are now stored at unit length, so each comparison is one multiplication pass (about 25 to 30% less work per search on large knowledge bases in our test). Existing vectors are converted in the background by the hourly check, with no API calls and the same results.
* Easier setup: clickable links and step-by-step instructions to get a free Gemini key, the connection is tested automatically after you save a key, and common key errors (wrong key, quota, model) come with a plain next step.
* Fix: links to uploaded files whose names contain capital letters (for example Price-List.pdf) were removed from answers on Linux servers as "unknown links". They are now recognised.
* Fix: creating a Knowledge Base with a hyphen in its name (for example "Price-List") failed because the hyphen ended up in the table name. New Knowledge Bases use letters, numbers and underscores only.
* Security: page, post, product and course titles in the source selection lists are escaped, and the saved selection is cleaned (known strategies only, numeric IDs).
* Select2 is bundled with the plugin instead of being loaded from cdn.jsdelivr.net.


= 1.7.6 =
* Fix (data safety): Knowledge Bases no longer drop the whole table when the field list is submitted empty, and removing or renaming a field (which deletes that column's data) now needs a confirmation tick. Field names are validated (letters, numbers, underscores; no duplicates or reserved names); existing names keep working. Failed database changes are reported and undone.
* Fix: CSV import handles empty files, files without a header, Excel's UTF-8 marker and non-UTF-8 files without PHP errors, and reports imported, duplicate, invalid and failed rows honestly (a failed save is never counted as imported). 10 MB / 20,000 row limits.
* Fix (security): rate limits are counted atomically (new table wp_ai_rate_limits), so many requests at the same moment can no longer pass the limit. Behind Cloudflare each visitor gets their own limit (the real visitor IP is used only when the request really comes from Cloudflare); other proxies can be trusted with the WP_AI_CHATBOT_TRUSTED_PROXIES constant.
* Fix (security): the chat session cookie must be a 32-character ID; anything else is replaced by a new random ID. Huge chat histories sent by scripts are cut before processing; nested values in lead forms are ignored; API keys are removed from stored error messages.
* Fix (WooCommerce): products hidden from the shop are never used by the chatbot; variable products are described with their price range ("from 5000 to 9000"), never one definite price; price and stock are read live when answering.
* Fix (answers): a price and its conditions ("does not include installation", "available separately for PKR 1,500") stay together; "Rs. 5,000" is no longer split from its currency; Roman Urdu sentences typed in lower case are split correctly; Urdu text is never sent 6x longer than its allowance.
* Fix (tokens): the request stays near its token target: old chat history is trimmed first (the latest reply and the question are always kept), several required items share the room fairly instead of overflowing, and a single very long list item is shortened.
* Improved: more Roman Urdu spellings and phrases ("kitne ka milega", "warrenty", "delivry"); "but not the refurbished one" / "X ke ilawa" are respected; partial name matches no longer outrank strong meaning-based matches; when a remembered item was removed, the bot says so instead of using another item.
* Improved (speed): vectors are stored in a compact binary format (about 2x faster search in our benchmark, smaller database); older vectors keep working and are converted in the background. Note: after updating, going back to 1.7.5 needs a "Train Chatbot" rebuild.

= 1.7.5 =
* Change: the AK Deep Knowledge logo is now built into the admin header and can no longer be changed. The "Admin branding" logo setting was removed; a logo saved earlier is ignored and cleared on the next settings save.
* Fix: the WordPress footer ("Thank you for creating with WordPress" and the version number) no longer shows over the plugin's forms.

= 1.7.3 =
* Fix: "All languages" voice sometimes produced timestamps ("00:00:00 - 00:00:02 ...") instead of the visitor's words. Gemini now returns a fixed answer shape (heard speech yes/no plus the words), timestamps, speaker labels and repeated filler are removed, and silence before and after the speech is cut in the browser before the clip is sent. A clip with no clear speech shows "Didn't catch that" and nothing is sent to the chat. Times a visitor says ("5:30 baje") are kept.

= 1.7.2 =
* New: voice input understands every language by default (Appearance > General > "Voice listens to: All languages"). English is written in English; Urdu and Hindi are written in Roman Urdu ("mujhe price batao"). The clip is turned into text with your Gemini API key (about 32 tokens per second of speech), stops by itself after a pause, is limited to 30 seconds, and is rate limited per visitor. Works in Chrome, Edge, Safari and Firefox on HTTPS sites. Voice cost is included in the Dashboard cost estimate.
* New: "One language only (strict)" keeps the previous behaviour: the browser's free speech recognition in the language you pick.
* Without a Gemini API key, "All languages" uses the browser's speech recognition in each visitor's browser language.

= 1.7.1 =
* Fix: evidence trimming picks the sentences that answer the question first (not the page introduction), keeps the condition or exception that follows ("Applies only to unopened products", "does not cover water damage"), keeps "It costs..." with the item it refers to, and matches English, Roman Urdu and Urdu wording (qeemat / price / قیمت). Reading order is restored.
* Fix: "show more" continues exactly after the last item shown, also when fewer than 10 items fitted, and works after the original question has left the chat history. The list (query, order, position) is kept per visitor on the server for 2 hours, every item is re-checked before it is shown, and a content change looks the remaining items up again without repeating any. A new question ends the list.
* Fix: follow-ups. "iski price?", "iski warranty?", "the second one" and "number 12" use the item the conversation is about (kept on the server, re-checked every time); a new question such as "What is your address?" is searched on its own instead of being mixed with the previous one. When "iski price?" could mean several listed items, the bot asks which one.
* New: exact title and SKU matches are found alongside meaning-based search, also when the embedding API fails; a failed search is no longer cached as "nothing found". Contact details are found from pages that really contain them (not every page that mentions "phones").
* Improved: the budget covers the whole request (instructions, forms, history, question and evidence) with a conservative token estimate for English and Urdu scripts; every sub-question of a multi-part question and every remembered item keeps its evidence.
* Token saver off: unchanged (same prompts as before the token saver).

= 1.7.0 =
* New: Token saver (AI Settings, on by default; untick to restore the previous behaviour). Sends the AI the most relevant passages within a size budget instead of up to 8 full records (40 for lists), keeps every item of comparisons and multi-part questions, never cuts a sentence in half, and keeps product name, price, currency, stock and links.
* New: "show all" lists 10 compact items at a time; "show more" continues without repeating items and the AI is told the list is not the complete catalogue.
* New: follow-ups such as "the second one" find the item from the bot's last list; "its price" keeps working.
* Improved: shorter instructions (same grounding, language, unknown-answer and form rules), old replies in the conversation are shortened, image cards in old replies become plain links.
* Improved: answer limits per request type, light thinking for Gemini 2.5 / 3 and OpenAI reasoning models (with one automatic retry if a model does not accept that option), and a reply that hits the limit ends at a complete sentence instead of mid-word. All calls, including any retry, are counted in the Dashboard usage.

= 1.6.2 =
* New: 10 professional chatbot icons: Typing Bubble, AI Spark, Conversation, Visor Bot, Orbit Bot, Voice Bot, Cube Bot, Capsule Bot, Live Bot and Help Bot.
* Changed: the Chat Icon gallery is grouped: chatbot icons first, then fun characters, then the classic bubble and your own icon.

= 1.6.1 =
* New: 20 more animated chat icons: Red Panda, Bunny, Foxy, Froggy, Penguin, Chick, Puppy, Busy Bee, Octo, Alien, UFO, Rocket, Fluffy, Cool Sun, Love, Donut, Chai, Retro Robo, Dino and Monster. Each one has its own moves (hops, winks, waddles, roars, buzzes...) and uses the same colour settings, greeting bubble and light / dark website options.

= 1.6.0 =
* New: Chat Icon tab under Appearance with six animated, interactive chat icons: AKDK Bot, Jelly, Kitty, Boo, Hoot and Support Buddy. Each one moves on its own (hops, waves, blinks, winks) and reacts when the visitor hovers over it.
* New: greeting bubble next to the icon ("Hi!" by default, editable). It pops up every few seconds and stops once the visitor has opened the chat.
* New: icon colours (body, face, eyes, details and outline) with AK Deep Knowledge colours by default, and versions for light websites, dark websites or automatic (follows the visitor's light or dark mode).
* New: use your own icon image or animated GIF from a link, or keep the classic round bubble.
* New: the live preview shows the chat icon under the chat window while you edit it.
* Changed: the AKDK Bot is the new default chat icon (sites that already used their own icon image keep it). Default icon size is now 64px.
* Animations are switched off for visitors who ask for reduced motion in their device settings.

= 1.5.3 =
* Fix: "Cannot modify header information - headers already sent" warnings during Process & Index on sites built with Elementor (or with shortcodes that print output). Anything printed while content is read for the knowledge base is now discarded, and the batch always returns to the Train Chatbot screen.

= 1.5.2 =
* Fix: knowledge items are marked complete only after every chunk is saved (one final step). An item interrupted half way, even by a time-out, is always indexed again.
* Changed: every item indexed by an older version is rebuilt once after updating (older versions had no completion marker). Run Process & Index once, or let the hourly check do it.
* Fix: if the database cannot save a verified lead, the webhook now answers with an error (503) so Zapier, n8n or Apps Script retry it. Only real duplicates are answered with "duplicate".
* Improved: price check knows currencies (USD 1500 is not accepted for a PKR 1500 price) and products (a product's price must belong to the product named in the sentence). Numbers such as SKUs are no longer treated as prices.
* Fix: for "show all" questions the AI is no longer told it has the complete list; it gets the best matches (up to 40) and is told more may exist.

= 1.5.1 =
* Fix: items indexed before 1.5.0 (one vector per page) are now rebuilt into chunks: automatically by the hourly check, or at once with Process & Index. A notice shows how many are left.
* Fix: indexing is all or nothing per item. If the AI provider fails half way, the previous index stays as it was and the item is retried; database write errors are reported and never shown as "complete".
* Fix: Process & Index no longer reports "Sync complete" while some source types were not processed yet (for example exactly 10 products and 1 page).
* Fix: unselecting a source (or a knowledge base) under Train Chatbot removes its vectors right away; search and background jobs also check the current selection.
* Fix: deleting knowledge base "faq" no longer removes the vectors of "faq_2".
* Improved: answer check compares numbers one by one (a $500 price is no longer accepted because "1500" is in the content), accepts only links that exist on your site, stricter phone matching, and replaces unsupported prices instead of only adding a note.
* Improved: verified leads are de-duplicated (submission ID from the webhook, entry ID from WordPress form plugins), and WordPress form submissions must come from the form set in the chat.
* Improved: the Dashboard cost includes knowledge base indexing and the admin assistant, and uses your model's prices (Dashboard, Design, Cost estimate).
* Changed: readme wording about sync timing, chunk limits and large knowledge bases.

= 1.5.0 =
* New: automatic knowledge sync. Saving or changing a selected page, post, product (including price and stock) or course queues it for re-indexing (run by WP-Cron); unpublished, private or deleted items are removed at once. Knowledge base rows sync when added, edited, imported or deleted. An hourly check catches anything missed.
* New: long content is split into overlapping chunks (about 1,600 characters each), so the end of long pages is searchable too. Bulk indexing also refreshes items changed since they were indexed.
* New: search covers the whole knowledge base in batches (the old 4,000-record limit is gone).
* New: exact token counts from the AI provider's usage report (prompt including retrieved knowledge and conversation, completion including thinking tokens).
* New: answer check removes links, emails and phone numbers that are not in your content and adds "please confirm" to unsupported prices. Flagged answers are counted on the Dashboard.
* New: verified leads for external forms (webhook for Google Forms, n8n, Zapier, Make; automatic for WordPress form plugins). Browser-reported submissions, bookings and add-to-cart are now tracked separately and are not counted as leads.
* Fix: search results are no longer served from cache after a page becomes private. Only matching IDs are cached and every result is re-checked; any content change clears the cache.
* Changed: readme wording about answer accuracy.

= 1.4.0 =
* New: Lead Forms can now be external. Choose a form type: built-in form, link or checkout (button), embedded page (Google Forms, Typeform, Calendly, JotForm), WordPress form shortcode (Contact Form 7, WPForms, Fluent Forms, Gravity Forms, WooCommerce) or embed code (HubSpot, Mailchimp, Zoho, Brevo).
* New: WordPress forms and embed code run inside the chat with automatic height.
* New: views, opens and completed submissions of external forms are tracked and counted as leads on the Dashboard and the Leads page.
* New: external forms work with quick actions and as the pre-chat form ("Continue to chat" button).
* Fix: disabled forms are no longer offered to the AI.

= 1.3.1 =
* Removed long dashes from all plugin text. Chatbot and Data Analyst replies no longer contain them either.

= 1.3.0 =
* New: dashboard redesign: KPI cards with trend lines, conversations & leads trend, busiest hours, leads by form, visitor journey, token usage, response time, system and knowledge-base panels. Built-in charts, no external chart library.
* New: Dashboard "Design" tab to choose chart colours and style (area fill, smooth curves, gridlines) with a live preview. Brand colours by default.
* New: your own logo in the admin header (AI Settings → Admin branding).
* New: close (X) button is solid red with a white icon by default; background, icon and hover colours are editable under Appearance → Input & Buttons. Theme button styles can no longer turn it white.
* Improved: setup stepper always shows step numbers, with a check badge for completed steps; Dashboard, Chat History and Leads moved to the top bar.
* Improved: Chat History and remaining admin screens use the AK Deep Knowledge colours.

= 1.2.0 =
* New: redesigned chat window with a compact message box with quick actions above it, slimmer borders, avatar and subtitle in the header, icon buttons.
* New: AK Deep Knowledge Light (default) and Dark themes.
* New: quick-action alignment (left, center, right).
* New: optional voice input and "Powered by" line (can be turned off).
* New: Appearance screen with tabs and a live preview.
* New: branded, full-width admin with numbered setup steps, progress and "next step" guidance; menu re-ordered in setup order.
* New: built-in Markdown rendering, so the chat widget no longer loads an external library.
* Improved: lead forms follow the chat theme (dark mode friendly); WhatsApp launcher opens on click.
* Improved: mobile layout for the widget and every admin screen.
* Fix: Knowledge Bases screen script error that stopped search and select-all.

= 1.1.0 =
* New: central AI client used by every feature; current default models (gemini-3.8-flash, gemini-embedding-2); retired Gemini models are replaced automatically.
* New: "Test Connection" button, admin notices for AI errors and for knowledge items that need re-indexing.
* New: WhatsApp launcher menu in the chat bubble (WhatsApp + AI chat).
* New: optional data clean-up on uninstall, readme.
* Fix: visitors on cached pages got "Invalid request" (403).
* Fix: knowledge-base vectors from different embedding models were compared with each other.
* Fix: when nothing matched, the bot could guess; it is now instructed to say it isn't sure and offer the contact form.
* Fix: technical API errors were shown to visitors; they now see a polite message and the admin sees the details.
* Fix: "Process & Index" could time out or fail with "headers already sent".
* Fix: the visitor's message was sent to the AI twice; conversation roles for Gemini.
* Fix: custom database records received links to unrelated posts.
* Fix: lead-form field names with hyphens or double spaces were not saved.
* Fix: a disabled or deleted pre-chat form no longer locks the chat.
* Fix: the chat widget no longer breaks when browser storage is blocked; inline form errors instead of pop-ups; keyboard support.
* Security: stricter sanitising of settings, appearance values and AI output.

= 1.0.0 =
* First release.
